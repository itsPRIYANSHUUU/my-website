import { useEffect, useState, useRef } from 'react';
import { 
  BookOpen, 
  GraduationCap, 
  FileText, 
  HelpCircle, 
  Trophy, 
  Phone, 
  Mail, 
  MapPin, 
  Facebook, 
  Instagram, 
  Youtube, 
  MessageCircle,
  Menu,
  X,
  ChevronRight,
  Star,
  Users,
  Award,
  Clock,
  CheckCircle,
  Play,
  Download,
  ArrowRight,
  TrendingUp,
  Mic
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Navigation Component
function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', href: '#home' },
    { name: 'Courses', href: '#courses' },
    { name: 'Study Material', href: '#study-material' },
    { name: 'Quiz', href: '#quiz' },
    { name: 'Toppers', href: '#toppers' },
    { name: 'About', href: '#about' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'glass shadow-lg' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <a href="#home" className="flex items-center gap-3">
            <img src="/images/logo.png" alt="ACE Logo" className="h-12 w-12 object-contain" />
            <div className="hidden sm:block">
              <span className="text-xl font-bold text-black">Amar's Classes</span>
              <span className="block text-xs text-orange-500">for English</span>
            </div>
          </a>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-sm font-medium text-gray-700 hover:text-orange-500 transition-colors relative group"
              >
                {link.name}
                <span className="absolute -bottom-1 left-1/2 w-0 h-0.5 bg-orange-500 transition-all duration-300 group-hover:w-full group-hover:left-0" />
              </a>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="hidden lg:flex items-center gap-4">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="ghost" className="text-sm font-medium">Login</Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-center">Welcome Back</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" type="email" placeholder="Enter your email" />
                  </div>
                  <div>
                    <Label htmlFor="password">Password</Label>
                    <Input id="password" type="password" placeholder="Enter your password" />
                  </div>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">Login</Button>
                  <p className="text-center text-sm text-gray-500">
                    Don't have an account? <span className="text-orange-500 cursor-pointer">Sign up</span>
                  </p>
                </div>
              </DialogContent>
            </Dialog>
            <Dialog>
              <DialogTrigger asChild>
                <Button className="bg-orange-500 hover:bg-orange-600 text-white shadow-orange">
                  Join Now
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-center">Create Account</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" placeholder="Enter your full name" />
                  </div>
                  <div>
                    <Label htmlFor="signup-email">Email</Label>
                    <Input id="signup-email" type="email" placeholder="Enter your email" />
                  </div>
                  <div>
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" placeholder="Enter your phone number" />
                  </div>
                  <div>
                    <Label htmlFor="signup-password">Password</Label>
                    <Input id="signup-password" type="password" placeholder="Create password" />
                  </div>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">Sign Up</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden glass border-t">
          <div className="px-4 py-4 space-y-3">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="block py-2 text-gray-700 hover:text-orange-500 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <div className="pt-4 space-y-2">
              <Button variant="outline" className="w-full">Login</Button>
              <Button className="w-full bg-orange-500 hover:bg-orange-600">Join Now</Button>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
}

// Hero Section
function HeroSection() {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section id="home" className="min-h-screen pt-20 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden">
      {/* Decorative Elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-orange-200 rounded-full blur-3xl opacity-30" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-orange-100 rounded-full blur-3xl opacity-40" />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className={`space-y-8 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full">
              <Star className="h-4 w-4 text-orange-500 fill-orange-500" />
              <span className="text-sm font-medium text-orange-700">Since 2010</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-black leading-tight">
              Master <span className="text-orange-500">English</span> & <span className="text-orange-500">Hindi</span> for Bihar Board Success
            </h1>
            
            <p className="text-lg text-gray-600 max-w-xl">
              Join Amar's Classes for English - Bihar's trusted coaching institute for Class 10, 11 & 12. 
              Expert guidance, comprehensive study materials, and proven results since 2010.
            </p>
            
            <div className="flex flex-wrap gap-4">
              <a href="#courses">
                <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white shadow-orange group">
                  Explore Courses
                  <ChevronRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </a>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="lg" variant="outline" className="border-2 border-orange-500 text-orange-500 hover:bg-orange-50">
                    Join Free
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-center">Start Learning Free</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label htmlFor="free-name">Full Name</Label>
                      <Input id="free-name" placeholder="Enter your name" />
                    </div>
                    <div>
                      <Label htmlFor="free-email">Email</Label>
                      <Input id="free-email" type="email" placeholder="Enter your email" />
                    </div>
                    <div>
                      <Label htmlFor="free-class">Class</Label>
                      <Input id="free-class" placeholder="Enter your class (10/11/12)" />
                    </div>
                    <Button className="w-full bg-orange-500 hover:bg-orange-600">Get Free Access</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
            
            {/* Stats */}
            <div className="flex flex-wrap gap-8 pt-4">
              <div className="animate-float">
                <div className="text-3xl font-bold text-orange-500">15+</div>
                <div className="text-sm text-gray-600">Years of Excellence</div>
              </div>
              <div className="animate-float-delayed">
                <div className="text-3xl font-bold text-orange-500">5000+</div>
                <div className="text-sm text-gray-600">Students Trained</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-orange-500">95%</div>
                <div className="text-sm text-gray-600">Success Rate</div>
              </div>
            </div>
          </div>
          
          {/* Hero Image */}
          <div className={`relative transition-all duration-1000 delay-300 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'}`}>
            <div className="relative">
              <img 
                src="/images/hero-student.jpg" 
                alt="Student Success" 
                className="rounded-3xl shadow-2xl w-full max-w-lg mx-auto"
              />
              {/* Floating Cards */}
              <div className="absolute -left-8 top-1/4 bg-white rounded-xl shadow-lg p-4 animate-float">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 rounded-full flex items-center justify-center">
                    <Trophy className="h-5 w-5 text-orange-500" />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Top Results</div>
                    <div className="text-xs text-gray-500">Every Year</div>
                  </div>
                </div>
              </div>
              <div className="absolute -right-4 bottom-1/4 bg-white rounded-xl shadow-lg p-4 animate-float-delayed">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  </div>
                  <div>
                    <div className="text-sm font-bold">Expert Faculty</div>
                    <div className="text-xs text-gray-500">15+ Years Exp.</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// About Section
function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    'Expert faculty with years of experience',
    'Comprehensive study materials',
    'Regular assessments and feedback',
    'Personalized attention to each student',
  ];

  return (
    <section id="about" ref={sectionRef} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image */}
          <div className={`relative transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'}`}>
            <div className="relative">
              <div className="absolute -inset-4 border-2 border-orange-500 rounded-3xl" />
              <img 
                src="/images/about-student.jpg" 
                alt="About Amar's Classes" 
                className="rounded-3xl shadow-xl w-full relative z-10"
              />
              {/* Experience Badge */}
              <div className="absolute -right-6 top-1/2 -translate-y-1/2 bg-orange-500 text-white rounded-2xl p-6 shadow-orange-lg z-20 animate-float">
                <div className="text-4xl font-bold">15+</div>
                <div className="text-sm">Years<br/>Experience</div>
              </div>
            </div>
          </div>
          
          {/* Content */}
          <div className={`space-y-6 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full">
              <Users className="h-4 w-4 text-orange-500" />
              <span className="text-sm font-medium text-orange-700">About Us</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-bold text-black">
              15+ Years of Excellence in Education
            </h2>
            
            <p className="text-gray-600">
              Since 2010, Amar's Classes for English has been the trusted choice for Bihar Board students. 
              We specialize in English and Hindi subjects for Classes 10, 11, and 12, along with comprehensive 
              Spoken English programs.
            </p>
            
            <p className="text-gray-600">
              Our mission is to provide quality education that empowers students to achieve their academic goals 
              and build a strong foundation for their future. With experienced faculty and proven teaching methods, 
              we have helped thousands of students excel in their board examinations.
            </p>
            
            <div className="space-y-4">
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className="flex items-center gap-3 group"
                  style={{ animationDelay: `${index * 100}ms` }}
                >
                  <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center group-hover:bg-orange-500 transition-colors">
                    <CheckCircle className="h-4 w-4 text-orange-500 group-hover:text-white transition-colors" />
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
            
            <Button className="bg-orange-500 hover:bg-orange-600 text-white shadow-orange group">
              Know More
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}

// Courses Section
function CoursesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const courses = [
    {
      title: 'Class 10 English & Hindi',
      description: 'Complete Bihar Board syllabus coverage for Class 10 students.',
      features: [
        'Complete Bihar Board syllabus coverage',
        'Chapter-wise notes and explanations',
        'Previous year question papers',
        'Regular tests and assessments',
      ],
      icon: BookOpen,
    },
    {
      title: 'Class 11 English & Hindi',
      description: 'Advanced concepts and in-depth learning for Class 11.',
      features: [
        'In-depth concept clarity',
        'Advanced grammar and literature',
        'Writing skills development',
        'Monthly progress reports',
      ],
      icon: GraduationCap,
    },
    {
      title: 'Class 12 English & Hindi',
      description: 'Board exam preparation and revision for Class 12.',
      features: [
        'Board exam preparation',
        'Model test papers',
        'Answer writing techniques',
        'Last-minute revision notes',
      ],
      icon: Trophy,
    },
  ];

  return (
    <section id="courses" ref={sectionRef} className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full mb-4">
            <BookOpen className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-700">Our Courses</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black mb-4">
            Comprehensive Programs for Every Student
          </h2>
          <p className="text-gray-600">
            Choose from our range of courses designed specifically for Bihar Board students.
          </p>
        </div>
        
        {/* Course Cards */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {courses.map((course, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-500 hover:-translate-y-2 group ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="w-14 h-14 bg-orange-100 rounded-xl flex items-center justify-center mb-6 group-hover:bg-orange-500 transition-colors">
                <course.icon className="h-7 w-7 text-orange-500 group-hover:text-white transition-colors" />
              </div>
              
              <h3 className="text-xl font-bold text-black mb-3">{course.title}</h3>
              <p className="text-gray-600 mb-6">{course.description}</p>
              
              <ul className="space-y-3 mb-8">
                {course.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start gap-2">
                    <CheckCircle className="h-5 w-5 text-orange-500 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-gray-600">{feature}</span>
                  </li>
                ))}
              </ul>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white group/btn">
                    Enroll Now
                    <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-2xl font-bold text-center">Enroll in {course.title}</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div>
                      <Label htmlFor={`enroll-name-${index}`}>Full Name</Label>
                      <Input id={`enroll-name-${index}`} placeholder="Enter your name" />
                    </div>
                    <div>
                      <Label htmlFor={`enroll-phone-${index}`}>Phone Number</Label>
                      <Input id={`enroll-phone-${index}`} placeholder="Enter your phone" />
                    </div>
                    <div>
                      <Label htmlFor={`enroll-email-${index}`}>Email</Label>
                      <Input id={`enroll-email-${index}`} type="email" placeholder="Enter your email" />
                    </div>
                    <Button className="w-full bg-orange-500 hover:bg-orange-600">Submit Enrollment</Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Study Material Section
function StudyMaterialSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const materials = [
    { title: 'PDF Notes', description: 'Chapter-wise detailed notes for quick revision', icon: FileText },
    { title: 'Video Lectures', description: 'Expert explanations of all topics', icon: Play },
    { title: 'Previous Year Papers', description: 'Practice with actual board exam papers', icon: FileText },
    { title: 'Sample Papers', description: 'Model tests for exam preparation', icon: FileText },
    { title: 'Grammar Tips', description: 'Essential grammar rules and tricks', icon: BookOpen },
    { title: 'Writing Formats', description: 'Letter, essay, and report formats', icon: FileText },
    { title: 'Literature Summary', description: 'Quick summaries of all chapters', icon: BookOpen },
    { title: 'Important Questions', description: 'Most likely questions for exams', icon: HelpCircle },
  ];

  return (
    <section id="study-material" ref={sectionRef} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full mb-4">
            <Download className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-700">Study Material</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black mb-4">
            Free Resources for Your Success
          </h2>
          <p className="text-gray-600">
            Access comprehensive study materials designed by expert faculty.
          </p>
        </div>
        
        {/* Material Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {materials.map((material, index) => (
            <div
              key={index}
              className={`bg-gray-50 rounded-xl p-6 hover:bg-white hover:shadow-lg transition-all duration-300 hover:-translate-y-1 group cursor-pointer ${
                isVisible ? 'opacity-100 scale-100' : 'opacity-0 scale-90'
              }`}
              style={{ transitionDelay: `${index * 80}ms` }}
            >
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-orange-500 transition-colors">
                <material.icon className="h-6 w-6 text-orange-500 group-hover:text-white transition-colors" />
              </div>
              <h3 className="text-lg font-semibold text-black mb-2">{material.title}</h3>
              <p className="text-sm text-gray-600 mb-4">{material.description}</p>
              <div className="flex items-center text-orange-500 text-sm font-medium">
                <Download className="h-4 w-4 mr-1" />
                <span>Download Free</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Quiz Section
function QuizSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    'Chapter-wise quizzes',
    'Instant results with explanations',
    'Track your progress',
    'Identify weak areas',
  ];

  return (
    <section id="quiz" ref={sectionRef} className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className={`space-y-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full">
              <HelpCircle className="h-4 w-4 text-orange-500" />
              <span className="text-sm font-medium text-orange-700">Practice Quiz</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-bold text-black">
              Test Your Knowledge
            </h2>
            
            <p className="text-gray-600">
              Practice with chapter-wise quizzes and track your progress. Get instant feedback 
              and improve your weak areas.
            </p>
            
            <div className="space-y-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-orange-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-orange-500" />
                  </div>
                  <span className="text-gray-700">{feature}</span>
                </div>
              ))}
            </div>
            
            <div className="flex gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold text-orange-500">100+</div>
                <div className="text-sm text-gray-600">Quizzes Available</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-orange-500">1000+</div>
                <div className="text-sm text-gray-600">Questions</div>
              </div>
            </div>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white shadow-orange">
                  Start Quiz
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-center">Select Quiz</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <Tabs defaultValue="class10" className="w-full">
                    <TabsList className="grid w-full grid-cols-3">
                      <TabsTrigger value="class10">Class 10</TabsTrigger>
                      <TabsTrigger value="class11">Class 11</TabsTrigger>
                      <TabsTrigger value="class12">Class 12</TabsTrigger>
                    </TabsList>
                    <TabsContent value="class10" className="space-y-3">
                      <Button variant="outline" className="w-full justify-between">English Grammar <ChevronRight className="h-4 w-4" /></Button>
                      <Button variant="outline" className="w-full justify-between">Hindi Grammar <ChevronRight className="h-4 w-4" /></Button>
                      <Button variant="outline" className="w-full justify-between">Literature <ChevronRight className="h-4 w-4" /></Button>
                    </TabsContent>
                    <TabsContent value="class11" className="space-y-3">
                      <Button variant="outline" className="w-full justify-between">English Grammar <ChevronRight className="h-4 w-4" /></Button>
                      <Button variant="outline" className="w-full justify-between">Hindi Grammar <ChevronRight className="h-4 w-4" /></Button>
                      <Button variant="outline" className="w-full justify-between">Literature <ChevronRight className="h-4 w-4" /></Button>
                    </TabsContent>
                    <TabsContent value="class12" className="space-y-3">
                      <Button variant="outline" className="w-full justify-between">English Grammar <ChevronRight className="h-4 w-4" /></Button>
                      <Button variant="outline" className="w-full justify-between">Hindi Grammar <ChevronRight className="h-4 w-4" /></Button>
                      <Button variant="outline" className="w-full justify-between">Literature <ChevronRight className="h-4 w-4" /></Button>
                    </TabsContent>
                  </Tabs>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          {/* Quiz Preview */}
          <div className={`relative transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'}`}>
            <div className="bg-white rounded-2xl shadow-xl p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <div className="text-sm text-gray-500">Question 5 of 20</div>
                  <div className="text-lg font-semibold">English Grammar Quiz</div>
                </div>
                <div className="w-16 h-16 border-4 border-orange-500 rounded-full flex items-center justify-center animate-pulse-slow">
                  <span className="text-lg font-bold">45</span>
                </div>
              </div>
              
              <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
                <div className="bg-orange-500 h-2 rounded-full" style={{ width: '25%' }} />
              </div>
              
              <div className="space-y-3">
                <p className="font-medium mb-4">Choose the correct form of the verb:</p>
                <Button variant="outline" className="w-full justify-start text-left">She ___ to school every day.</Button>
                <Button variant="outline" className="w-full justify-start text-left">go</Button>
                <Button variant="outline" className="w-full justify-start text-left border-orange-500 bg-orange-50">goes</Button>
                <Button variant="outline" className="w-full justify-start text-left">going</Button>
              </div>
            </div>
            
            {/* Floating decorations */}
            <div className="absolute -top-4 -right-4 w-12 h-12 bg-orange-500 rounded-full flex items-center justify-center text-white animate-float">
              <HelpCircle className="h-6 w-6" />
            </div>
            <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-black rounded-full flex items-center justify-center text-white animate-float-delayed">
              <CheckCircle className="h-6 w-6" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Spoken English Section
function SpokenEnglishSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    'Basic to Advanced Levels',
    'Interview Preparation',
    'Group Discussions',
    'Presentation Skills',
    'Pronunciation Training',
    'Vocabulary Building',
  ];

  return (
    <section ref={sectionRef} className="py-20 bg-black relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src="/images/spoken-english.jpg" 
          alt="Spoken English" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div className={`space-y-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'}`}>
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-500/20 rounded-full">
              <Mic className="h-4 w-4 text-orange-500" />
              <span className="text-sm font-medium text-orange-400">Spoken English</span>
            </div>
            
            <h2 className="text-3xl sm:text-4xl font-bold text-white">
              Speak English with Confidence
            </h2>
            
            <p className="text-gray-300">
              Our Spoken English program helps you master communication skills for interviews, 
              presentations, and daily conversations.
            </p>
            
            <div className="grid sm:grid-cols-2 gap-4">
              {features.map((feature, index) => (
                <div key={index} className="flex items-center gap-3">
                  <div className="w-6 h-6 bg-orange-500 rounded-full flex items-center justify-center">
                    <CheckCircle className="h-4 w-4 text-white" />
                  </div>
                  <span className="text-gray-300">{feature}</span>
                </div>
              ))}
            </div>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button size="lg" className="bg-orange-500 hover:bg-orange-600 text-white shadow-orange">
                  Join Now
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md">
                <DialogHeader>
                  <DialogTitle className="text-2xl font-bold text-center">Join Spoken English</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 pt-4">
                  <div>
                    <Label htmlFor="spoken-name">Full Name</Label>
                    <Input id="spoken-name" placeholder="Enter your name" />
                  </div>
                  <div>
                    <Label htmlFor="spoken-phone">Phone Number</Label>
                    <Input id="spoken-phone" placeholder="Enter your phone" />
                  </div>
                  <div>
                    <Label htmlFor="spoken-level">Current Level</Label>
                    <Input id="spoken-level" placeholder="Beginner/Intermediate/Advanced" />
                  </div>
                  <Button className="w-full bg-orange-500 hover:bg-orange-600">Enroll Now</Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          {/* Floating Badges */}
          <div className={`relative h-64 lg:h-auto transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'}`}>
            <div className="absolute top-0 right-1/4 bg-orange-500 text-white rounded-xl px-6 py-4 animate-float">
              <div className="text-2xl font-bold">Confidence</div>
            </div>
            <div className="absolute top-1/3 right-0 bg-white text-black rounded-xl px-6 py-4 animate-float-delayed">
              <div className="text-2xl font-bold">Fluency</div>
            </div>
            <div className="absolute bottom-1/4 right-1/3 bg-orange-500 text-white rounded-xl px-6 py-4 animate-float">
              <div className="text-2xl font-bold">Interview Ready</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// Toppers Section
function ToppersSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const toppers = [
    {
      name: 'Rahul Kumar',
      class: 'Class 12',
      year: '2023',
      marks: '95%',
      subject: 'English',
      quote: "Amar Sir's guidance helped me score top marks.",
      image: '/images/topper1.jpg',
    },
    {
      name: 'Priya Sharma',
      class: 'Class 10',
      year: '2023',
      marks: '94%',
      subject: 'Hindi',
      quote: 'The study materials and quizzes were game-changers.',
      image: '/images/topper2.jpg',
    },
    {
      name: 'Amit Singh',
      class: 'Class 11',
      year: '2022',
      marks: '92%',
      subject: 'English',
      quote: 'Best coaching institute in Patna!',
      image: '/images/topper3.jpg',
    },
    {
      name: 'Neha Gupta',
      class: 'Class 12',
      year: '2022',
      marks: '96%',
      subject: 'Hindi',
      quote: 'Personal attention made all the difference.',
      image: '/images/topper4.jpg',
    },
    {
      name: 'Vikash Roy',
      class: 'Class 10',
      year: '2022',
      marks: '93%',
      subject: 'English',
      quote: 'Thank you for helping me succeed!',
      image: '/images/topper5.jpg',
    },
  ];

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % toppers.length);
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + toppers.length) % toppers.length);
  };

  return (
    <section id="toppers" ref={sectionRef} className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full mb-4">
            <Trophy className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-700">Our Toppers</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black mb-4">
            Success Stories That Inspire
          </h2>
          <p className="text-gray-600">
            Meet our brilliant students who achieved outstanding results in Bihar Board examinations.
          </p>
        </div>
        
        {/* Carousel */}
        <div className={`relative transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="flex items-center justify-center gap-4">
            {/* Previous Button */}
            <button 
              onClick={prevSlide}
              className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"
            >
              <ChevronRight className="h-6 w-6 rotate-180" />
            </button>
            
            {/* Cards */}
            <div className="flex gap-6 overflow-hidden py-8">
              {toppers.map((topper, index) => {
                const isActive = index === activeIndex;
                const isPrev = index === (activeIndex - 1 + toppers.length) % toppers.length;
                const isNext = index === (activeIndex + 1) % toppers.length;
                
                if (!isActive && !isPrev && !isNext) return null;
                
                return (
                  <div
                    key={index}
                    className={`bg-white rounded-2xl shadow-lg p-6 transition-all duration-500 ${
                      isActive ? 'scale-100 opacity-100 z-10' : 'scale-90 opacity-60'
                    } ${isPrev ? '-translate-x-4' : ''} ${isNext ? 'translate-x-4' : ''}`}
                    style={{ minWidth: '320px', maxWidth: '320px' }}
                  >
                    <div className="flex flex-col items-center text-center">
                      <div className="w-24 h-24 rounded-full overflow-hidden mb-4 border-4 border-orange-500">
                        <img src={topper.image} alt={topper.name} className="w-full h-full object-cover" />
                      </div>
                      <h3 className="text-xl font-bold text-black">{topper.name}</h3>
                      <p className="text-sm text-gray-500 mb-2">{topper.class}, {topper.year}</p>
                      <div className="inline-flex items-center gap-2 px-3 py-1 bg-orange-100 rounded-full mb-4">
                        <span className="text-lg font-bold text-orange-500">{topper.marks}</span>
                        <span className="text-sm text-orange-700">in {topper.subject}</span>
                      </div>
                      <p className="text-gray-600 italic">"{topper.quote}"</p>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {/* Next Button */}
            <button 
              onClick={nextSlide}
              className="w-12 h-12 bg-white rounded-full shadow-lg flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"
            >
              <ChevronRight className="h-6 w-6" />
            </button>
          </div>
          
          {/* Dots */}
          <div className="flex justify-center gap-2 mt-6">
            {toppers.map((_, index) => (
              <button
                key={index}
                onClick={() => setActiveIndex(index)}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === activeIndex ? 'bg-orange-500' : 'bg-gray-300'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

// Stats Section
function StatsSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const stats = [
    { value: '15+', label: 'Years of Excellence', icon: Clock },
    { value: '5000+', label: 'Students Trained', icon: Users },
    { value: '95%', label: 'Success Rate', icon: TrendingUp },
    { value: '50+', label: 'Awards Won', icon: Award },
  ];

  return (
    <section ref={sectionRef} className="py-16 bg-orange-500">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className={`text-center text-white transition-all duration-700 ${
                isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-slow">
                <stat.icon className="h-8 w-8" />
              </div>
              <div className="text-4xl font-bold mb-2">{stat.value}</div>
              <div className="text-orange-100">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// Contact Section
function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const contactInfo = [
    { icon: Phone, label: 'Phone', value: '+91 98765 43210' },
    { icon: Mail, label: 'Email', value: 'info@amarsclasses.com' },
    { icon: MapPin, label: 'Address', value: '123 Education Street, Patna, Bihar' },
  ];

  return (
    <section id="contact" ref={sectionRef} className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className={`text-center max-w-3xl mx-auto mb-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-orange-100 rounded-full mb-4">
            <MessageCircle className="h-4 w-4 text-orange-500" />
            <span className="text-sm font-medium text-orange-700">Contact Us</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-black mb-4">
            Get In Touch
          </h2>
          <p className="text-gray-600">
            Have questions? We'd love to hear from you.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Info */}
          <div className={`space-y-6 transition-all duration-700 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-20'}`}>
            {contactInfo.map((info, index) => (
              <div 
                key={index} 
                className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl hover:bg-white hover:shadow-lg transition-all"
              >
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <info.icon className="h-6 w-6 text-orange-500" />
                </div>
                <div>
                  <div className="text-sm text-gray-500">{info.label}</div>
                  <div className="font-medium text-black">{info.value}</div>
                </div>
              </div>
            ))}
            
            {/* Social Links */}
            <div className="flex gap-4 pt-4">
              {[Facebook, Instagram, Youtube, MessageCircle].map((Icon, index) => (
                <a
                  key={index}
                  href="#"
                  className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center hover:bg-orange-500 hover:text-white transition-colors"
                >
                  <Icon className="h-5 w-5" />
                </a>
              ))}
            </div>
          </div>
          
          {/* Contact Form */}
          <div className={`bg-gray-50 rounded-2xl p-8 transition-all duration-700 delay-200 ${isVisible ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-20'}`}>
            <form className="space-y-6">
              <div>
                <Label htmlFor="contact-name">Full Name</Label>
                <Input id="contact-name" placeholder="Enter your name" className="bg-white" />
              </div>
              <div>
                <Label htmlFor="contact-email">Email Address</Label>
                <Input id="contact-email" type="email" placeholder="Enter your email" className="bg-white" />
              </div>
              <div>
                <Label htmlFor="contact-phone">Phone Number</Label>
                <Input id="contact-phone" placeholder="Enter your phone" className="bg-white" />
              </div>
              <div>
                <Label htmlFor="contact-message">Message</Label>
                <Textarea id="contact-message" placeholder="Write your message..." className="bg-white min-h-[120px]" />
              </div>
              <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white shadow-orange">
                Send Message
              </Button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}

// Footer Section
function Footer() {
  return (
    <footer className="bg-black text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Logo & About */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <img src="/images/logo.png" alt="ACE Logo" className="h-12 w-12 object-contain" />
              <div>
                <span className="text-lg font-bold">Amar's Classes</span>
                <span className="block text-xs text-orange-500">for English</span>
              </div>
            </div>
            <p className="text-gray-400 text-sm">
              Empowering students for Bihar Board success since 2010. Quality education for English and Hindi subjects.
            </p>
          </div>
          
          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2">
              {['Home', 'About Us', 'Courses', 'Contact'].map((link) => (
                <li key={link}>
                  <a href={`#${link.toLowerCase().replace(' ', '-')}`} className="text-gray-400 hover:text-orange-500 transition-colors text-sm">
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Courses */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Courses</h4>
            <ul className="space-y-2">
              {['Class 10 English & Hindi', 'Class 11 English & Hindi', 'Class 12 English & Hindi', 'Spoken English'].map((course) => (
                <li key={course}>
                  <a href="#courses" className="text-gray-400 hover:text-orange-500 transition-colors text-sm">
                    {course}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          
          {/* Newsletter */}
          <div>
            <h4 className="text-lg font-semibold mb-4">Newsletter</h4>
            <p className="text-gray-400 text-sm mb-4">Subscribe for updates and study tips.</p>
            <div className="flex gap-2">
              <Input placeholder="Enter your email" className="bg-gray-800 border-gray-700 text-white" />
              <Button className="bg-orange-500 hover:bg-orange-600 px-4">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
        
        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-gray-400 text-sm">
            © 2024 Amar's Classes for English. All rights reserved.
          </p>
          <div className="flex gap-4">
            {[Facebook, Instagram, Youtube, MessageCircle].map((Icon, index) => (
              <a
                key={index}
                href="#"
                className="w-10 h-10 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-orange-500 transition-colors"
              >
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

// Main App Component
function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <HeroSection />
      <AboutSection />
      <CoursesSection />
      <StudyMaterialSection />
      <QuizSection />
      <SpokenEnglishSection />
      <ToppersSection />
      <StatsSection />
      <ContactSection />
      <Footer />
    </div>
  );
}

export default App;
