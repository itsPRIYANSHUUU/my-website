# GitHub Pages Setup Guide for Amar's Classes

## Step 1: Create GitHub Account

1. Go to: https://github.com
2. Click **"Sign up"** button (top right)
3. Fill in details:
   - **Username:** `amarsclasses` (or choose your own)
   - **Email:** Your email address
   - **Password:** Create a strong password
4. Click **"Create account"**
5. Verify your email (check inbox for GitHub email)

---

## Step 2: Create a New Repository

1. After login, click **"+"** icon (top right) → **"New repository"**
2. Fill in:
   - **Repository name:** `amars-classes-website`
   - **Description:** `Amar's Classes for English - Coaching Institute Website`
   - **Public:** Select this option (free)
   - **Add a README:** Check this box
3. Click **"Create repository"**

---

## Step 3: Upload Website Files

### Method A: Drag & Drop (Easiest)

1. Download the ZIP file I provided: `amars-classes-website.zip`
2. Extract it on your computer
3. Go to your GitHub repository
4. Click **"Add file"** → **"Upload files"**
5. Drag all files from the extracted folder
6. Click **"Commit changes"**

### Method B: Using Git (Advanced)

Skip this if you're not technical.

---

## Step 4: Enable GitHub Pages

1. In your repository, click **"Settings"** tab
2. Scroll down to **"Pages"** section (left sidebar)
3. Under **"Source"**, select:
   - Branch: `main`
   - Folder: `/ (root)`
4. Click **"Save"**
5. Wait 2-5 minutes
6. Your site will be live at: `https://amarsclasses.github.io/amars-classes-website`

---

## Step 5: Connect Your Custom Domain

### In GitHub:

1. In repository Settings → Pages
2. Under **"Custom domain"**, enter: `Englishwithamarsir.online`
3. Click **"Save"**
4. Check **"Enforce HTTPS"** (for security)

### In Your Domain Provider (where you bought Englishwithamarsir.online):

You need to add these DNS records:

**For Root Domain (Englishwithamarsir.online):**
```
Type: A
Name: @
Value: 185.199.108.153

Type: A
Name: @
Value: 185.199.109.153

Type: A
Name: @
Value: 185.199.110.153

Type: A
Name: @
Value: 185.199.111.153
```

**For WWW (www.Englishwithamarsir.online):**
```
Type: CNAME
Name: www
Value: amarsclasses.github.io
```

---

## Step 6: Wait for DNS Propagation

- DNS changes take 24-48 hours to work everywhere
- Your site will be live at: `https://Englishwithamarsir.online`

---

## Troubleshooting

### Site not showing?
- Check if files are uploaded correctly
- Make sure GitHub Pages is enabled
- Wait 5 minutes after enabling

### Domain not working?
- Check DNS records are correct
- Wait 24-48 hours
- Verify domain in GitHub settings

---

## Need Help?

If you get stuck at any step, just tell me:
1. Which step you're on
2. What error you see
3. I'll help you fix it!

---

## Your Website Files Location

All your website files are in:
`/mnt/okcomputer/output/amars-classes-website.zip`

Download this ZIP file and extract it before uploading to GitHub.
